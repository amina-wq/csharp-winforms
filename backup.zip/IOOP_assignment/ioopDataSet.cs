﻿namespace IOOP_assignment
{


    partial class ioopDataSet
    {
    }
}

namespace IOOP_assignment.ioopDataSetTableAdapters
{
    partial class OrderItemTableAdapter
    {
    }

    public partial class OrderTableAdapter 
    {

    }
}
