﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_assignment.Models
{
    public class SQLConnect
    {
        private SqlConnection conn = new SqlConnection();
    }
}
