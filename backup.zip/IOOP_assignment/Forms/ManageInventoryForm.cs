﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_assignment.Forms
{
    public partial class ManageInventoryForm : Form
    {
        public ManageInventoryForm()
        {
            InitializeComponent();
        }
        bool _DropDown = true;
        public static bool IsHidden { get; private set; }
        private void ManageInventoryForm_Load(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (_DropDown == true)
            {
                DropdownPanel.Height += 30;
                if (DropdownPanel.Height < 250) return;
                timer1.Stop();
                _DropDown = false;
            }
            else
            {
                {
                    DropdownPanel.Height -= 30;
                    if (DropdownPanel.Height > 10) return;
                    timer1.Stop();
                    _DropDown = true;
                }
            }
        }

        private void DropDown_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ChefDashboard chefDashboard = new ChefDashboard();
            chefDashboard.Show();
            this.Close();
        }

        private void btnViewOrder_Click(object sender, EventArgs e)
        {
            ViewOrdersForm viewOrdersForm = new ViewOrdersForm();
            viewOrdersForm.Show();
            this.Close();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You're already in this page.");
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            ChefProfileForm chefProfileForm = new ChefProfileForm();
            chefProfileForm.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ViewOrdersForm viewOrdersForm = new ViewOrdersForm();
            viewOrdersForm.Show();
            this.Close();
        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
          
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
        }
    }
}
