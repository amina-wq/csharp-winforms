﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace IOOP_assignment.Forms
{
    public partial class OrderDetails : Form
    {
        public OrderDetails()
        {
            InitializeComponent();
        }
        
        public void SetTableNumber(string tableNumber)
        {
            lblTableNum.Text = "TABLE " + tableNumber;
        }
        bool _DropDown = true;
        public static bool IsHidden { get; private set; }

        private void OrderDetails_Load(object sender, EventArgs e)
        {
           
        }

        private void DropDown_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if (_DropDown == true)
            {
                DropdownPanel.Height += 30;
                if (DropdownPanel.Height < 250) return;
                timer1.Stop();
                _DropDown = false;
            }
            else
            {
                {
                    DropdownPanel.Height -= 30;
                    if (DropdownPanel.Height > 10) return;
                    timer1.Stop();
                    _DropDown = true;
                }
            }
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ChefDashboard chefDashboard = new ChefDashboard();
            chefDashboard.Show();
            this.Close();
        }

        private void btnViewOrder_Click(object sender, EventArgs e)
        {
            ViewOrdersForm viewOrdersForm = new ViewOrdersForm();
            viewOrdersForm.Show();
            this.Close();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            ManageInventoryForm manageInventoryForm = new ManageInventoryForm();
            manageInventoryForm.Show();
            this.Close();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            ChefProfileForm chefProfileForm = new ChefProfileForm();
            chefProfileForm.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ViewOrdersForm viewOrdersForm = new ViewOrdersForm();
            viewOrdersForm.Show();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
        }

        private void btnReceiveOrder_Click(object sender, EventArgs e)
        {

        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }
    }
}
